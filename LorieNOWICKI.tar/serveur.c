#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <semaphore.h> // Ajout de l'en-tête pour les sémaphores

#define SHM_NAME "/communication_segment"
#define BUFFER_SIZE 1024

int main() {
    const char *message = "Message from the server";
    sem_t sem; // Déclaration du sémaphore

    // Initialisation du sémaphore
    if (sem_init(&sem, 1, 1) == -1) {
        perror("Erreur lors de l'initialisation du sémaphore");
        exit(EXIT_FAILURE);
    }

    // Création du segment de mémoire partagée
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("Erreur lors de la création du segment de mémoire partagée");
        exit(EXIT_FAILURE);
    }

    // Définition de la taille du segment de mémoire partagée
    if (ftruncate(shm_fd, BUFFER_SIZE) == -1) {
        perror("Erreur lors de la définition de la taille du segment de mémoire partagée");
        exit(EXIT_FAILURE);
    }

    // Attachement du segment de mémoire partagée à l'espace d'adressage du serveur
    char *shm_ptr = mmap(0, BUFFER_SIZE, PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("Erreur lors de l'attachement du segment de mémoire partagée");
        exit(EXIT_FAILURE);
    }

    // Attente pour acquérir le sémaphore
    if (sem_wait(&sem) == -1) {
        perror("Erreur lors de l'attente pour acquérir le sémaphore");
        exit(EXIT_FAILURE);
    }

    // Écriture des données dans le segment de mémoire partagée
    strcpy(shm_ptr, message);

    printf("Serveur : Données écrites dans le segment de mémoire partagée.\n");

    // Libération du sémaphore
    if (sem_post(&sem) == -1) {
        perror("Erreur lors de la libération du sémaphore");
        exit(EXIT_FAILURE);
    }

    // Attente que le client lise les données
    printf("Serveur : Attente que le client lise les données...\n");
    sleep(10); // Temps d'attente arbitraire

    // Libération des ressources
    munmap(shm_ptr, BUFFER_SIZE);
    close(shm_fd);
    shm_unlink(SHM_NAME);
    sem_destroy(&sem); // Destruction du sémaphore

    return 0;
}
