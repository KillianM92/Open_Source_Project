#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h> // Ajout de l'en-tête pour les sémaphores

#define SHM_NAME "/communication_segment"
#define BUFFER_SIZE 1024

int main() {
    sem_t sem; // Déclaration du sémaphore

    // Initialisation du sémaphore
    if (sem_init(&sem, 1, 1) == -1) {
        perror("Erreur lors de l'initialisation du sémaphore");
        exit(EXIT_FAILURE);
    }

    // Ouverture du segment de mémoire partagée créé par le serveur
    int shm_fd = shm_open(SHM_NAME, O_RDONLY, 0666);
    if (shm_fd == -1) {
        perror("Erreur lors de l'ouverture du segment de mémoire partagée");
        exit(EXIT_FAILURE);
    }

    // Attachement du segment de mémoire partagée à l'espace d'adressage du client
    char *shm_ptr = mmap(0, BUFFER_SIZE, PROT_READ, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("Erreur lors de l'attachement du segment de mémoire partagée");
        exit(EXIT_FAILURE);
    }

    // Lecture des données écrites par le serveur
    printf("Client : Données lues depuis le segment de mémoire partagée : %s\n", shm_ptr);

    // Libération des ressources
    munmap(shm_ptr, BUFFER_SIZE);
    close(shm_fd);
    sem_destroy(&sem); // Destruction du sémaphore

    return 0;
}
